const sql = require('mssql');
require('dotenv').config(); // Carga las variables del archivo .env

const dbConfig = {
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    server: process.env.DB_SERVER,
    database: process.env.DB_NAME,
    options: {
        encrypt: false,
        trustServerCertificate: true,
        // GETDATE() en SQL Server devuelve la hora LOCAL del servidor (no UTC).
        // Sin esto, tedious asume que esos valores ya vienen en UTC al construir
        // el Date de JS, y luego el navegador le resta el offset otra vez al
        // mostrarlo -> las fechas se ven corridas por el huso horario local (ej.
        // 5 horas atrás en Colombia). useUTC:false hace que el driver interprete
        // el valor tal cual como hora local, que es justo lo que GETDATE() da.
        useUTC: false
    }
};

let poolPromise = null;

// Reutilizamos un único pool de conexiones para toda la app en vez de abrir
// uno nuevo por cada request (mssql permite varias conexiones concurrentes
// sobre el mismo pool).
const getConnection = async () => {
    try {
        if (!poolPromise) {
            poolPromise = new sql.ConnectionPool(dbConfig).connect();
            poolPromise.catch(() => {
                // Si falla la conexión inicial, permitimos reintentar en la próxima llamada
                poolPromise = null;
            });
        }
        return await poolPromise;
    } catch (error) {
        console.error('Error al conectar a SQL Server:', error);
        throw error;
    }
};

module.exports = { getConnection, sql };