require('dotenv').config({ path: require('path').resolve(__dirname, '../.env') });
const { getConnection, sql } = require('../config/database');

// Migración one-off para el módulo de Reportes y Márgenes de Ganancia.
const statements = [
  ['Columna de costo histórico en DetalleVentas', `
    ALTER TABLE DetalleVentas ADD CostoUnitario DECIMAL(18,2) NULL;
  `],
  ['Permiso nuevo', `
    INSERT INTO Permisos (Codigo, Descripcion) VALUES
        ('reportes.ver', 'Ver reportes de ventas, márgenes, kardex e inventario');
  `],
  ['Permisos de Contador (reportes.ver + compras.ver + devoluciones.ver, solo lectura)', `
    INSERT INTO RolPermisos (RolId, PermisoId)
    SELECT r.Id, p.Id FROM Roles r CROSS JOIN Permisos p
    WHERE r.Nombre = 'Contador' AND p.Codigo IN ('reportes.ver', 'compras.ver', 'devoluciones.ver');
  `],
  ['MenuItems: Reportes', `
    INSERT INTO MenuItems (Etiqueta, Ruta, Icono, PermisoId, Orden, Activo)
    SELECT 'Reportes', 'reportes', 'mdi mdi-chart-line', p.Id,
           (SELECT ISNULL(MAX(Orden), 0) + 1 FROM MenuItems), 1
    FROM Permisos p WHERE p.Codigo = 'reportes.ver';
  `],
];

async function migrar() {
  const pool = await getConnection();
  const transaction = new sql.Transaction(pool);
  try {
    await transaction.begin();
    for (const [nombre, batch] of statements) {
      console.log(`Ejecutando: ${nombre}...`);
      await new sql.Request(transaction).batch(batch);
    }
    await transaction.commit();
    console.log('Migración completada con éxito.');
    process.exit(0);
  } catch (error) {
    await transaction.rollback();
    console.error('Error en la migración, se revirtió todo:', error.message);
    process.exit(1);
  }
}

migrar();
