const { getConnection } = require('../config/database');

const probarConexion = async () => {
    try {
        console.log('Intentando conectar a SQL Server...');
        const pool = await getConnection();
        
        // Ejecutamos una consulta sencilla para verificar la conexión
        const resultado = await pool.request().query('SELECT GETDATE() AS FechaActual');
        
        console.log('¡Conexión exitosa a SQL Server!');
        console.log('Fecha y hora del servidor de base de datos:', resultado.recordset[0].FechaActual);
        
        // Cerramos la conexión de prueba
        await pool.close();
        process.exit(0);
    } catch (error) {
        console.error('Error al conectar con la base de datos:', error.message);
        process.exit(1);
    }
};

probarConexion();