require('dotenv').config({ path: require('path').resolve(__dirname, '../.env') });
const { getConnection, sql } = require('../config/database');

// Migración one-off para el módulo de Compras y Proveedores.
// Se ejecuta cada sentencia en su propia transacción-batch para aislar errores
// y facilitar el diagnóstico si algo ya existe.
const statements = [
  ['Tabla Proveedores', `
    CREATE TABLE Proveedores (
        Id            INT IDENTITY(1,1) PRIMARY KEY,
        RazonSocial   NVARCHAR(150) NOT NULL,
        NIT           VARCHAR(30)   NOT NULL,
        Telefono      VARCHAR(20)   NULL,
        Correo        VARCHAR(100)  NULL,
        Direccion     NVARCHAR(200) NULL,
        Contacto      NVARCHAR(100) NULL,
        Activo        BIT           NOT NULL DEFAULT 1,
        FechaCreacion DATETIME      NOT NULL DEFAULT GETDATE(),
        CONSTRAINT UQ_Proveedores_NIT UNIQUE (NIT)
    );
  `],
  ['Tabla OrdenesCompra', `
    CREATE TABLE OrdenesCompra (
        Id            INT IDENTITY(1,1) PRIMARY KEY,
        ProveedorId   INT NOT NULL FOREIGN KEY REFERENCES Proveedores(Id),
        UsuarioId     INT NOT NULL FOREIGN KEY REFERENCES Usuarios(Id),
        FechaCreacion DATETIME NOT NULL DEFAULT GETDATE(),
        FechaEsperada DATE NULL,
        Estado        VARCHAR(20) NOT NULL DEFAULT 'PENDIENTE'
                      CHECK (Estado IN ('PENDIENTE','RECIBIDA_PARCIAL','RECIBIDA_TOTAL','CANCELADA')),
        Total         DECIMAL(18,2) NOT NULL DEFAULT 0,
        Observaciones NVARCHAR(500) NULL
    );
    CREATE INDEX IX_OrdenesCompra_ProveedorId ON OrdenesCompra(ProveedorId);
    CREATE INDEX IX_OrdenesCompra_Estado ON OrdenesCompra(Estado);
  `],
  ['Tabla DetalleOrdenesCompra', `
    CREATE TABLE DetalleOrdenesCompra (
        Id                INT IDENTITY(1,1) PRIMARY KEY,
        OrdenCompraId     INT NOT NULL FOREIGN KEY REFERENCES OrdenesCompra(Id),
        ProductoId        INT NOT NULL FOREIGN KEY REFERENCES Productos(Id),
        CantidadPedida    INT NOT NULL CHECK (CantidadPedida > 0),
        CantidadRecibida  INT NOT NULL DEFAULT 0,
        CostoUnitario     DECIMAL(18,2) NOT NULL,
        Subtotal          DECIMAL(18,2) NOT NULL
    );
    CREATE INDEX IX_DetalleOrdenesCompra_OrdenCompraId ON DetalleOrdenesCompra(OrdenCompraId);
    CREATE INDEX IX_DetalleOrdenesCompra_ProductoId ON DetalleOrdenesCompra(ProductoId);
  `],
  ['Tabla RecepcionesCompra', `
    CREATE TABLE RecepcionesCompra (
        Id              INT IDENTITY(1,1) PRIMARY KEY,
        OrdenCompraId   INT NOT NULL FOREIGN KEY REFERENCES OrdenesCompra(Id),
        UsuarioId       INT NOT NULL FOREIGN KEY REFERENCES Usuarios(Id),
        FechaRecepcion  DATETIME NOT NULL DEFAULT GETDATE(),
        Observaciones   NVARCHAR(500) NULL
    );
    CREATE INDEX IX_RecepcionesCompra_OrdenCompraId ON RecepcionesCompra(OrdenCompraId);
  `],
  ['Tabla DetalleRecepcionesCompra', `
    CREATE TABLE DetalleRecepcionesCompra (
        Id                    INT IDENTITY(1,1) PRIMARY KEY,
        RecepcionCompraId     INT NOT NULL FOREIGN KEY REFERENCES RecepcionesCompra(Id),
        DetalleOrdenCompraId  INT NOT NULL FOREIGN KEY REFERENCES DetalleOrdenesCompra(Id),
        CantidadRecibida      INT NOT NULL CHECK (CantidadRecibida > 0),
        CostoUnitario         DECIMAL(18,2) NOT NULL
    );
    CREATE INDEX IX_DetalleRecepcionesCompra_RecepcionCompraId ON DetalleRecepcionesCompra(RecepcionCompraId);
    CREATE INDEX IX_DetalleRecepcionesCompra_DetalleOrdenCompraId ON DetalleRecepcionesCompra(DetalleOrdenCompraId);
  `],
  ['Permisos nuevos', `
    INSERT INTO Permisos (Codigo, Descripcion) VALUES
        ('proveedores.ver',    'Ver proveedores'),
        ('proveedores.crear',  'Crear proveedores'),
        ('proveedores.editar', 'Editar proveedores'),
        ('compras.ver',        'Ver órdenes de compra'),
        ('compras.crear',      'Crear órdenes de compra'),
        ('compras.recibir',    'Registrar recepción de mercancía'),
        ('compras.cancelar',   'Cancelar órdenes de compra');
  `],
  ['Permisos de Almacen (ver/recibir)', `
    INSERT INTO RolPermisos (RolId, PermisoId)
    SELECT r.Id, p.Id
    FROM Roles r
    CROSS JOIN Permisos p
    WHERE r.Nombre = 'Almacen'
      AND p.Codigo IN ('compras.ver', 'compras.recibir');
  `],
  ['MenuItems: Compras y Proveedores', `
    INSERT INTO MenuItems (Etiqueta, Ruta, Icono, PermisoId, Orden, Activo)
    SELECT 'Compras', 'compras', 'mdi mdi-cart-arrow-down', p.Id,
           (SELECT ISNULL(MAX(Orden), 0) + 1 FROM MenuItems), 1
    FROM Permisos p WHERE p.Codigo = 'compras.ver';

    INSERT INTO MenuItems (Etiqueta, Ruta, Icono, PermisoId, Orden, Activo)
    SELECT 'Proveedores', 'proveedores', 'mdi mdi-truck-delivery', p.Id,
           (SELECT ISNULL(MAX(Orden), 0) + 1 FROM MenuItems), 1
    FROM Permisos p WHERE p.Codigo = 'proveedores.ver';
  `],
];

async function migrar() {
  const pool = await getConnection();
  const transaction = new sql.Transaction(pool);
  try {
    await transaction.begin();
    for (const [nombre, batch] of statements) {
      console.log(`Ejecutando: ${nombre}...`);
      await new sql.Request(transaction).batch(batch);
    }
    await transaction.commit();
    console.log('Migración completada con éxito.');
    process.exit(0);
  } catch (error) {
    await transaction.rollback();
    console.error('Error en la migración, se revirtió todo:', error.message);
    process.exit(1);
  }
}

migrar();
