require('dotenv').config({ path: require('path').resolve(__dirname, '../.env') });
const bcrypt = require('bcrypt');
const { getConnection, sql } = require('../config/database');

async function crearAdmin() {
  const nombre = 'admin'; // cámbialo
  const correo = 'admin@miscelanea.com'; // cámbialo
  const contrasenaPlano = '123456789'; // cámbiala y bórrala del código después

  const contrasenaHasheada = await bcrypt.hash(contrasenaPlano, 10);

  const pool = await getConnection();
  const rol = await pool.request().query("SELECT Id FROM Roles WHERE Nombre = 'Administrador'");
  const rolId = rol.recordset[0].Id;

  await pool.request()
    .input('Nombre', sql.NVarChar, nombre)
    .input('Correo', sql.NVarChar, correo)
    .input('Contrasena', sql.NVarChar, contrasenaHasheada)
    .input('RolId', sql.Int, rolId)
    .query(`
      INSERT INTO Usuarios (Nombre, Correo, Contrasena, RolId, Activo, FechaCreacion)
      VALUES (@Nombre, @Correo, @Contrasena, @RolId, 1, GETDATE())
    `);

  console.log('Administrador creado con éxito:', correo);
  process.exit(0);
}

crearAdmin().catch((err) => {
  console.error('Error al crear administrador:', err);
  process.exit(1);
});