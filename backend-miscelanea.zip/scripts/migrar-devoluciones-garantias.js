require('dotenv').config({ path: require('path').resolve(__dirname, '../.env') });
const { getConnection, sql } = require('../config/database');

// Migración one-off para el módulo de Devoluciones y Garantías.
const statements = [
  ['Recrear cabecera DevolucionesGarantias (0 filas, sin FKs entrantes)', `
    DROP TABLE DevolucionesGarantias;

    CREATE TABLE DevolucionesGarantias (
        Id                INT IDENTITY(1,1) PRIMARY KEY,
        VentaId           INT NOT NULL FOREIGN KEY REFERENCES Ventas(Id),
        UsuarioId         INT NOT NULL FOREIGN KEY REFERENCES Usuarios(Id),
        FechaRegistro     DATETIME NOT NULL DEFAULT GETDATE(),
        Estado            VARCHAR(20) NOT NULL DEFAULT 'PENDIENTE'
                          CHECK (Estado IN ('PENDIENTE','AUTORIZADA','RECHAZADA')),
        UsuarioAutorizaId INT NULL FOREIGN KEY REFERENCES Usuarios(Id),
        FechaAutorizacion DATETIME NULL,
        Observaciones     NVARCHAR(500) NULL
    );
    CREATE INDEX IX_DevolucionesGarantias_VentaId ON DevolucionesGarantias(VentaId);
    CREATE INDEX IX_DevolucionesGarantias_Estado ON DevolucionesGarantias(Estado);
  `],
  ['Tabla DetalleDevolucionesGarantias', `
    CREATE TABLE DetalleDevolucionesGarantias (
        Id                    INT IDENTITY(1,1) PRIMARY KEY,
        DevolucionGarantiaId  INT NOT NULL FOREIGN KEY REFERENCES DevolucionesGarantias(Id),
        DetalleVentaId        INT NOT NULL FOREIGN KEY REFERENCES DetalleVentas(Id),
        ProductoId            INT NOT NULL FOREIGN KEY REFERENCES Productos(Id),
        Cantidad              INT NOT NULL CHECK (Cantidad > 0),
        MotivoCodigo          VARCHAR(30) NOT NULL
                              CHECK (MotivoCodigo IN ('DEFECTUOSO','NO_ERA_LO_ESPERADO','GARANTIA','OTRO')),
        ReingresaStock        BIT NOT NULL DEFAULT 0,
        TipoResolucion        VARCHAR(20) NOT NULL CHECK (TipoResolucion IN ('REEMBOLSO','CAMBIO')),
        ProductoReemplazoId   INT NULL FOREIGN KEY REFERENCES Productos(Id)
    );
    CREATE INDEX IX_DetalleDevolucionesGarantias_DevolucionGarantiaId ON DetalleDevolucionesGarantias(DevolucionGarantiaId);
    CREATE INDEX IX_DetalleDevolucionesGarantias_DetalleVentaId ON DetalleDevolucionesGarantias(DetalleVentaId);
    CREATE INDEX IX_DetalleDevolucionesGarantias_ProductoId ON DetalleDevolucionesGarantias(ProductoId);
  `],
  ['Columna de control anti sobre-devolución en DetalleVentas', `
    ALTER TABLE DetalleVentas ADD CantidadDevuelta INT NOT NULL DEFAULT 0;
  `],
  ['Permisos nuevos', `
    INSERT INTO Permisos (Codigo, Descripcion) VALUES
        ('devoluciones.ver',       'Ver devoluciones y garantías'),
        ('devoluciones.crear',     'Registrar solicitudes de devolución'),
        ('devoluciones.autorizar', 'Autorizar o rechazar devoluciones (ejecuta el movimiento de stock)');
  `],
  ['Permisos de Cajero (ver/crear)', `
    INSERT INTO RolPermisos (RolId, PermisoId)
    SELECT r.Id, p.Id FROM Roles r CROSS JOIN Permisos p
    WHERE r.Nombre = 'Cajero' AND p.Codigo IN ('devoluciones.ver','devoluciones.crear');
  `],
  ['Permisos de Almacen (ver/autorizar)', `
    INSERT INTO RolPermisos (RolId, PermisoId)
    SELECT r.Id, p.Id FROM Roles r CROSS JOIN Permisos p
    WHERE r.Nombre = 'Almacen' AND p.Codigo IN ('devoluciones.ver','devoluciones.autorizar');
  `],
  ['MenuItems: Devoluciones', `
    INSERT INTO MenuItems (Etiqueta, Ruta, Icono, PermisoId, Orden, Activo)
    SELECT 'Devoluciones', 'devoluciones', 'mdi mdi-keyboard-return', p.Id,
           (SELECT ISNULL(MAX(Orden), 0) + 1 FROM MenuItems), 1
    FROM Permisos p WHERE p.Codigo = 'devoluciones.ver';
  `],
];

async function migrar() {
  const pool = await getConnection();
  const transaction = new sql.Transaction(pool);
  try {
    await transaction.begin();
    for (const [nombre, batch] of statements) {
      console.log(`Ejecutando: ${nombre}...`);
      await new sql.Request(transaction).batch(batch);
    }
    await transaction.commit();
    console.log('Migración completada con éxito.');
    process.exit(0);
  } catch (error) {
    await transaction.rollback();
    console.error('Error en la migración, se revirtió todo:', error.message);
    process.exit(1);
  }
}

migrar();
