const { getConnection, sql } = require('../config/database');

class ProductoModel {

    static async buscarPorCodigoONombre(busqueda) {
        try {
            const pool = await getConnection();
            const result = await pool.request()
                .input('busqueda', sql.VarChar, busqueda)
                .query(`
                    SELECT p.*, c.Nombre AS Categoria 
                    FROM Productos p
                    JOIN Categorias c ON p.CategoriaId = c.Id
                    WHERE p.CodigoBarras = @busqueda OR p.Nombre LIKE '%' + @busqueda + '%'
                `);
            return result.recordset;
        } catch (error) {
            console.error('Error al buscar producto:', error);
            throw error;
        }
    }

    static async mostrarTodosLosProductos() {
        try {
            const pool = await getConnection();
            const result = await pool.request()
                .query(`
                    SELECT p.*, c.Nombre AS Categoria 
                    FROM Productos p
                    JOIN Categorias c ON p.CategoriaId = c.Id
                `);
            return result.recordset;
        } catch (error) {
            console.error('Error al mostrar productos:', error);
            throw error;
        }
    }

    static async registrarProducto(datosProducto) {
        try {
            const pool = await getConnection();
            const result = await pool.request()
                .input('CodigoBarras', sql.VarChar, datosProducto.CodigoBarras)
                .input('Nombre', sql.VarChar, datosProducto.Nombre)
                // .input('Descripcion', sql.VarChar, datosProducto.Descripcion) // Comentado o eliminado si la columna no existe
                .input('PrecioVenta', sql.Decimal(18, 2), datosProducto.PrecioVenta)
                .input('PrecioCosto', sql.Decimal(18, 2), datosProducto.PrecioCosto) // Añadir PrecioCosto
                .input('Stock', sql.Int, datosProducto.Stock)
                .input('StockMinimo', sql.Int, datosProducto.StockMinimo)
                .input('CategoriaId', sql.Int, datosProducto.CategoriaId)
                .query(`
                    INSERT INTO Productos (CodigoBarras, Nombre, PrecioVenta, PrecioCosto, Stock, StockMinimo, CategoriaId)
                    OUTPUT INSERTED.Id
                    VALUES (@CodigoBarras, @Nombre, @PrecioVenta, @PrecioCosto, @Stock, @StockMinimo, @CategoriaId)
                `);
            return { id: result.recordset[0].Id };
        } catch (error) {
            console.error('Error al registrar producto:', error);
            throw error;
        }
    }

    static async actualizarProducto(id, datosProducto) {
        try {
            const { CodigoBarras, Nombre, PrecioVenta, PrecioCosto, Stock, StockMinimo, CategoriaId } = datosProducto;
            const pool = await getConnection();
            await pool.request()
                .input('Id', sql.Int, id)
                .input('CodigoBarras', sql.VarChar, CodigoBarras)
                .input('Nombre', sql.VarChar, Nombre)
                .input('PrecioVenta', sql.Decimal(18, 2), PrecioVenta)
                .input('PrecioCosto', sql.Decimal(18, 2), PrecioCosto)
                .input('Stock', sql.Int, Stock)
                .input('StockMinimo', sql.Int, StockMinimo)
                .input('CategoriaId', sql.Int, CategoriaId)
                .query(`
                    UPDATE Productos
                    SET 
                        CodigoBarras = @CodigoBarras,
                        Nombre = @Nombre,
                        PrecioVenta = @PrecioVenta,
                        PrecioCosto = @PrecioCosto,
                        Stock = @Stock,
                        StockMinimo = @StockMinimo,
                        CategoriaId = @CategoriaId,
                        FechaActualizacion = GETDATE()
                    WHERE Id = @Id
                `);
            return { id };
        } catch (error) {
            console.error('Error al actualizar producto:', error);
            throw error;
        }
    }

    static async eliminarProducto(id) {
        try {
            const pool = await getConnection();
            await pool.request()
                .input('Id', sql.Int, id)
                .query('DELETE FROM Productos WHERE Id = @Id');
            return { id };
        } catch (error) {
            console.error('Error al eliminar producto:', error);
            throw error;
        }
    }
}

module.exports = ProductoModel;